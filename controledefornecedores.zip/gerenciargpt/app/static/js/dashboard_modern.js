/**
 * GerenciarGPT - Dashboard JavaScript Modular
 * Versão 2.0 - Refatorado e Melhorado
 */

class DashboardApp {
    constructor() {
        this.init();
    }

    init() {
        // Aguarda DOM estar pronto
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }
    }

    setup() {
        console.log('🚀 Inicializando GerenciarGPT Dashboard v2.0');
        
        // Inicializar módulos
        this.initializeComponents();
        this.bindEvents();
        
        console.log('✅ Dashboard inicializado com sucesso!');
    }

    initializeComponents() {
        // Inicializar toast notifications
        this.toast = new ToastManager();
        
        // Inicializar funcionalidades específicas baseadas na página
        if (this.isElementPresent('#accountsTable')) {
            this.accountManager = new AccountManager(this.toast);
        }
        
        if (this.isElementPresent('#provider-list')) {
            this.providerManager = new ProviderManager(this.toast);
        }
        
        if (this.isElementPresent('#searchInput')) {
            this.searchFilter = new SearchAndFilter();
        }
        
        if (this.isElementPresent('.sortable')) {
            this.tableSort = new TableSorter();
        }
        
        // Inicializar gráficos se existirem dados
        if (window.chartData) {
            this.chartManager = new ChartManager(window.chartData);
        }
    }

    bindEvents() {
        // Eventos globais
        this.bindGlobalEvents();
        
        // Bind de hotkeys úteis
        this.bindHotkeys();
    }

    bindGlobalEvents() {
        // Interceptar formulários AJAX para loading states
        document.addEventListener('submit', (e) => {
            const form = e.target;
            if (form.classList.contains('ajax-form')) {
                this.handleAjaxFormSubmit(e);
            }
        });
        
        // Auto-save em campos específicos
        document.addEventListener('input', this.debounce((e) => {
            if (e.target.classList.contains('auto-save')) {
                this.handleAutoSave(e.target);
            }
        }, 1000));
    }

    bindHotkeys() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + K para busca
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                const searchInput = document.getElementById('searchInput');
                if (searchInput) {
                    searchInput.focus();
                }
            }
            
            // ESC para fechar modais
            if (e.key === 'Escape') {
                const openModal = document.querySelector('.modal.show');
                if (openModal) {
                    const modal = bootstrap.Modal.getInstance(openModal);
                    modal?.hide();
                }
            }
        });
    }

    handleAjaxFormSubmit(e) {
        const form = e.target;
        const submitButton = form.querySelector('[type="submit"]');
        
        if (submitButton) {
            const originalText = submitButton.textContent;
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processando...';
            
            // Restaurar estado após timeout (fallback)
            setTimeout(() => {
                submitButton.disabled = false;
                submitButton.textContent = originalText;
            }, 10000);
        }
    }

    handleAutoSave(input) {
        // Implementar auto-save se necessário
        console.log('Auto-save triggered for:', input.name);
    }

    // Utilitários
    isElementPresent(selector) {
        return document.querySelector(selector) !== null;
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

class ToastManager {
    constructor() {
        this.createToastContainer();
    }

    createToastContainer() {
        // Verificar se já existe container de toast
        if (!document.getElementById('toast-container')) {
            const container = document.createElement('div');
            container.id = 'toast-container';
            container.className = 'toast-container position-fixed top-0 end-0 p-3';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }
    }

    show(title, message, type = 'success', duration = 4000) {
        const toastId = 'toast-' + Date.now();
        const iconClass = this.getIconClass(type);
        const bgClass = this.getBgClass(type);
        
        const toastHTML = `
            <div id="${toastId}" class="toast align-items-center ${bgClass} border-0" role="alert">
                <div class="d-flex">
                    <div class="toast-body text-white d-flex align-items-center">
                        <i class="${iconClass} me-2"></i>
                        <div>
                            <strong>${title}</strong>
                            <div class="small">${message}</div>
                        </div>
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                            data-bs-dismiss="toast"></button>
                </div>
            </div>
        `;

        const container = document.getElementById('toast-container');
        container.insertAdjacentHTML('beforeend', toastHTML);
        
        const toastElement = document.getElementById(toastId);
        const toast = new bootstrap.Toast(toastElement, { delay: duration });
        toast.show();
        
        // Remover elemento após esconder
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
        
        return toast;
    }

    success(title, message, duration) {
        return this.show(title, message, 'success', duration);
    }

    error(title, message, duration) {
        return this.show(title, message, 'error', duration);
    }

    warning(title, message, duration) {
        return this.show(title, message, 'warning', duration);
    }

    info(title, message, duration) {
        return this.show(title, message, 'info', duration);
    }

    getIconClass(type) {
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        return icons[type] || icons.info;
    }

    getBgClass(type) {
        const classes = {
            success: 'bg-success',
            error: 'bg-danger',
            warning: 'bg-warning',
            info: 'bg-info'
        };
        return classes[type] || classes.info;
    }
}

class AccountManager {
    constructor(toast) {
        this.toast = toast;
        this.table = document.getElementById('accountsTable');
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        // Editar conta
        this.table.addEventListener('click', (e) => {
            if (e.target.closest('.btn-edit')) {
                e.preventDefault();
                this.handleEdit(e.target.closest('.btn-edit'));
            }
        });

        // Ver credenciais
        this.table.addEventListener('click', (e) => {
            if (e.target.closest('.btn-view-credentials')) {
                e.preventDefault();
                this.handleViewCredentials(e.target.closest('.btn-view-credentials'));
            }
        });

        // Excluir conta
        this.table.addEventListener('click', (e) => {
            if (e.target.closest('.btn-delete-site')) {
                e.preventDefault();
                this.handleDelete(e.target.closest('.btn-delete-site'));
            }
        });

        // Submit do formulário de edição
        const editForm = document.getElementById('editAccountForm');
        if (editForm) {
            editForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleUpdate(editForm);
            });
        }

        // Submit do formulário de adicionar site
        const addForm = document.getElementById('addSiteForm');
        if (addForm) {
            addForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAdd(addForm);
            });
        }

        // Copiar senha
        const copyBtn = document.getElementById('copyPasswordBtn');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => this.handleCopyPassword());
        }
    }

    handleEdit(button) {
        const data = button.dataset;
        
        // Preencher modal
        document.getElementById('modalContaId').value = data.contaId;
        document.getElementById('editModalLabel').textContent = `Editar Conta: ${data.site}`;
        document.getElementById('modalLogin').value = data.login || '';
        document.getElementById('modalSenha').value = '';
        document.getElementById('modalStatus').value = data.status || '';
        
        // Formatar saldo (remover R$ e formatar para input)
        const saldo = (data.saldo || '0').toString().replace('R$', '').trim().replace('.', ',');
        document.getElementById('modalSaldo').value = saldo;
        
        // Mostrar lucro atual
        const lucroAtual = (data.lucro || '0').toString().replace('R$', '').trim();
        document.getElementById('modalLucroAtual').textContent = lucroAtual;
        
        // Mostrar modal
        const modal = new bootstrap.Modal(document.getElementById('editModal'));
        modal.show();
    }

    async handleViewCredentials(button) {
        const contaId = button.dataset.contaId;
        const baseUrl = this.table.dataset.credentialsUrlBase;
        
        try {
            const response = await fetch(`${baseUrl}/${contaId}`);
            const data = await response.json();
            
            if (data.success) {
                document.getElementById('viewLogin').textContent = data.login || 'N/A';
                document.getElementById('viewSenha').value = data.senha || '';
                
                const modal = new bootstrap.Modal(document.getElementById('viewCredentialsModal'));
                modal.show();
            } else {
                this.toast.error('Erro', data.message);
            }
        } catch (error) {
            this.toast.error('Erro', 'Erro de conexão com o servidor');
            console.error('Erro ao buscar credenciais:', error);
        }
    }

    async handleDelete(button) {
        const contaId = button.dataset.contaId;
        const siteName = button.dataset.siteName;
        const deleteUrl = document.getElementById('addSiteForm').dataset.deleteUrl;
        
        if (!confirm(`Tem certeza que deseja excluir a conta do site "${siteName}"?`)) {
            return;
        }

        try {
            const formData = new FormData();
            formData.append('conta_id', contaId);
            
            const response = await fetch(deleteUrl, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.toast.success('Sucesso', data.message);
                
                // Remover linha da tabela com animação
                const row = document.getElementById(`conta-${contaId}`);
                if (row) {
                    row.style.transition = 'opacity 0.3s';
                    row.style.opacity = '0';
                    setTimeout(() => row.remove(), 300);
                }
            } else {
                this.toast.error('Erro', data.message);
            }
        } catch (error) {
            this.toast.error('Erro de Rede', 'Não foi possível conectar ao servidor');
            console.error('Erro ao excluir conta:', error);
        }
    }

    async handleUpdate(form) {
        const updateUrl = form.dataset.url;
        const formData = new FormData(form);
        
        try {
            const response = await fetch(updateUrl, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.toast.success('Sucesso', data.message);
                
                // Fechar modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('editModal'));
                modal.hide();
                
                // Recarregar página para atualizar dados
                setTimeout(() => location.reload(), 1000);
            } else {
                this.toast.error('Erro', data.message);
            }
        } catch (error) {
            this.toast.error('Erro de Rede', 'Não foi possível conectar ao servidor');
            console.error('Erro ao atualizar conta:', error);
        }
    }

    async handleAdd(form) {
        const addUrl = form.dataset.url;
        const formData = new FormData(form);
        
        try {
            const response = await fetch(addUrl, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.toast.success('Sucesso', data.message);
                
                // Fechar modal e limpar formulário
                const modal = bootstrap.Modal.getInstance(document.getElementById('addSiteModal'));
                modal.hide();
                form.reset();
                
                // Recarregar para mostrar nova conta
                setTimeout(() => location.reload(), 1000);
            } else {
                this.toast.error('Erro', data.message);
            }
        } catch (error) {
            this.toast.error('Erro de Rede', 'Não foi possível conectar ao servidor');
            console.error('Erro ao adicionar conta:', error);
        }
    }

    handleCopyPassword() {
        const passwordField = document.getElementById('viewSenha');
        
        if (passwordField && passwordField.value) {
            // Usar API moderna de clipboard se disponível
            if (navigator.clipboard) {
                navigator.clipboard.writeText(passwordField.value)
                    .then(() => {
                        this.toast.success('Sucesso', 'Senha copiada para a área de transferência');
                    })
                    .catch(() => {
                        // Fallback para método antigo
                        this.fallbackCopyPassword(passwordField);
                    });
            } else {
                this.fallbackCopyPassword(passwordField);
            }
        }
    }

    fallbackCopyPassword(field) {
        field.select();
        field.setSelectionRange(0, 99999); // Para mobile
        
        try {
            document.execCommand('copy');
            this.toast.success('Sucesso', 'Senha copiada para a área de transferência');
        } catch (err) {
            this.toast.error('Erro', 'Não foi possível copiar a senha');
            console.error('Erro ao copiar:', err);
        }
    }
}

class ProviderManager {
    constructor(toast) {
        this.toast = toast;
        this.providerList = document.getElementById('provider-list');
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        // Adicionar fornecedor
        const addForm = document.getElementById('addProviderForm');
        if (addForm) {
            addForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAdd(addForm);
            });
        }

        // Excluir fornecedor
        this.providerList.addEventListener('click', (e) => {
            if (e.target.closest('.btn-delete')) {
                e.preventDefault();
                e.stopPropagation();
                this.handleDelete(e.target.closest('.btn-delete'));
            }
        });
    }

    async handleAdd(form) {
        const addUrl = form.dataset.url;
        const formData = new FormData(form);
        
        try {
            const response = await fetch(addUrl, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.toast.success('Sucesso', 'Fornecedor adicionado');
                
                // Fechar modal e limpar formulário
                const modal = bootstrap.Modal.getInstance(document.getElementById('addProviderModal'));
                modal.hide();
                form.reset();
                
                // Adicionar à lista
                this.addProviderToList(data.provider);
            } else {
                this.toast.error('Erro', data.message || 'Erro ao adicionar fornecedor');
            }
        } catch (error) {
            this.toast.error('Erro de Rede', 'Não foi possível conectar ao servidor');
            console.error('Erro ao adicionar fornecedor:', error);
        }
    }

    async handleDelete(button) {
        const providerId = button.dataset.providerId;
        const providerName = button.dataset.providerName;
        const deleteUrl = document.getElementById('addProviderForm').dataset.deleteUrl;
        
        if (!confirm(`Tem certeza que deseja excluir ${providerName} e TODAS as suas contas?`)) {
            return;
        }

        try {
            const formData = new FormData();
            formData.append('id_fornecedor', providerId);
            
            const response = await fetch(deleteUrl, {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.toast.success('Sucesso', `${providerName} foi excluído`);
                
                // Remover da lista
                const listItem = document.getElementById(`provider-${providerId}`);
                if (listItem) {
                    listItem.remove();
                }
                
                // Redirecionar se estiver na página do fornecedor excluído
                if (window.location.pathname.includes(`/provider/${providerId}`)) {
                    const indexUrl = document.getElementById('addProviderForm').dataset.indexUrl;
                    window.location.href = indexUrl;
                }
            } else {
                this.toast.error('Erro', data.message || 'Erro ao excluir fornecedor');
            }
        } catch (error) {
            this.toast.error('Erro de Rede', 'Não foi possível conectar ao servidor');
            console.error('Erro ao excluir fornecedor:', error);
        }
    }

    addProviderToList(provider) {
        const newProviderLink = `/provider/${provider.id}`;
        const listItem = `
            <li class="nav-item" id="provider-${provider.id}">
                <a href="${newProviderLink}" class="nav-link list-group-item d-flex justify-content-between align-items-center">
                    <span class="text-truncate">
                        <i class="nav-icon fas fa-user me-2"></i>${provider.nome}
                    </span>
                    <button class="btn btn-danger btn-sm btn-delete" 
                            data-provider-id="${provider.id}" 
                            data-provider-name="${provider.nome}" 
                            title="Excluir Fornecedor"
                            aria-label="Excluir fornecedor ${provider.nome}">
                        <i class="fas fa-trash"></i>
                    </button>
                </a>
            </li>
        `;
        
        // Adicionar antes do último item (botão de adicionar)
        const lastChild = this.providerList.children[this.providerList.children.length - 1];
        lastChild.insertAdjacentHTML('beforebegin', listItem);
    }
}

class SearchAndFilter {
    constructor() {
        this.searchInput = document.getElementById('searchInput');
        this.filterButtons = document.querySelectorAll('.filter-status');
        this.tableRows = document.querySelectorAll('#accountsTable tbody tr');
        
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        // Busca em tempo real
        if (this.searchInput) {
            this.searchInput.addEventListener('input', this.debounce((e) => {
                this.handleSearch(e.target.value);
            }, 300));
        }

        // Filtros por status
        this.filterButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.handleFilter(e.target);
            });
        });
    }

    handleSearch(query) {
        const searchTerm = query.toLowerCase().trim();
        
        this.tableRows.forEach(row => {
            const text = row.textContent.toLowerCase();
            const matches = text.includes(searchTerm);
            
            row.style.display = matches ? '' : 'none';
        });
        
        this.updateResultsCount();
    }

    handleFilter(button) {
        const status = button.dataset.status?.toLowerCase() || '';
        
        // Atualizar estado dos botões
        this.filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Aplicar filtro
        this.tableRows.forEach(row => {
            if (!status) {
                row.style.display = '';
                return;
            }
            
            const statusCell = row.querySelector('.status-cell');
            if (statusCell) {
                const rowStatus = statusCell.textContent.toLowerCase();
                row.style.display = rowStatus.includes(status) ? '' : 'none';
            }
        });
        
        this.updateResultsCount();
    }

    updateResultsCount() {
        const visibleRows = Array.from(this.tableRows).filter(row => 
            row.style.display !== 'none'
        ).length;
        
        // Mostrar contador se existir elemento para isso
        const counter = document.getElementById('results-counter');
        if (counter) {
            counter.textContent = `${visibleRows} resultado(s)`;
        }
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

class TableSorter {
    constructor() {
        this.sortableHeaders = document.querySelectorAll('.sortable');
        this.tableBody = document.querySelector('#accountsTable tbody');
        
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        this.sortableHeaders.forEach(header => {
            header.addEventListener('click', (e) => {
                this.handleSort(e.target);
            });
        });
    }

    handleSort(header) {
        const column = parseInt(header.dataset.column);
        const currentDirection = header.classList.contains('sort-asc') ? 'asc' : 'desc';
        const newDirection = currentDirection === 'asc' ? 'desc' : 'asc';
        
        // Limpar todas as classes de ordenação
        this.sortableHeaders.forEach(h => {
            h.classList.remove('sort-asc', 'sort-desc');
        });
        
        // Aplicar nova direção
        header.classList.add(`sort-${newDirection}`);
        
        // Ordenar linhas
        const rows = Array.from(this.tableBody.querySelectorAll('tr'));
        
        rows.sort((a, b) => {
            const aValue = this.getCellValue(a, column);
            const bValue = this.getCellValue(b, column);
            
            return this.compareValues(aValue, bValue, newDirection);
        });
        
        // Reordenar DOM
        rows.forEach(row => this.tableBody.appendChild(row));
    }

    getCellValue(row, column) {
        const cell = row.querySelectorAll('td')[column];
        if (!cell) return '';
        
        let value = cell.textContent.trim();
        
        // Se é coluna de valor monetário (saldo ou lucro)
        if (column === 2 || column === 3) {
            value = this.parseCurrency(value);
        }
        
        return value;
    }

    parseCurrency(value) {
        // Remover R$ e converter para número
        return parseFloat(
            value.replace('R$', '')
                 .replace(/\./g, '')
                 .replace(',', '.')
                 .trim()
        ) || 0;
    }

    compareValues(a, b, direction) {
        let result = 0;
        
        if (typeof a === 'number' && typeof b === 'number') {
            result = a - b;
        } else {
            result = a.toString().localeCompare(b.toString(), 'pt-BR', { numeric: true });
        }
        
        return direction === 'asc' ? result : -result;
    }
}

class ChartManager {
    constructor(data) {
        this.data = data;
        this.charts = {};
        
        this.init();
    }

    init() {
        // Aguardar Chart.js estar disponível
        if (typeof Chart !== 'undefined') {
            this.initializeCharts();
        } else {
            // Aguardar carregamento do Chart.js
            setTimeout(() => this.init(), 100);
        }
    }

    initializeCharts() {
        this.createSiteChart();
        this.createStatusChart();
    }

    createSiteChart() {
        const canvas = document.getElementById('siteChart');
        if (!canvas || !this.data.sites) return;
        
        const ctx = canvas.getContext('2d');
        
        this.charts.site = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: this.data.sites.labels,
                datasets: [{
                    label: 'Lucro por Site (R$)',
                    data: this.data.sites.data,
                    backgroundColor: 'rgba(54, 162, 235, 0.8)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toLocaleString('pt-BR', {
                                    minimumFractionDigits: 2
                                });
                            }
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Lucro: R$ ' + context.parsed.y.toLocaleString('pt-BR', {
                                    minimumFractionDigits: 2
                                });
                            }
                        }
                    }
                }
            }
        });
    }

    createStatusChart() {
        const canvas = document.getElementById('statusChart');
        if (!canvas || !this.data.status) return;
        
        const ctx = canvas.getContext('2d');
        
        this.charts.status = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: this.data.status.labels,
                datasets: [{
                    data: this.data.status.data,
                    backgroundColor: [
                        'rgba(75, 192, 192, 0.8)',
                        'rgba(54, 162, 235, 0.8)',
                        'rgba(255, 206, 86, 0.8)',
                        'rgba(153, 102, 255, 0.8)'
                    ],
                    borderColor: [
                        'rgba(75, 192, 192, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    // Método para atualizar gráficos quando dados mudarem
    updateCharts(newData) {
        this.data = newData;
        
        if (this.charts.site) {
            this.charts.site.data.labels = newData.sites.labels;
            this.charts.site.data.datasets[0].data = newData.sites.data;
            this.charts.site.update();
        }
        
        if (this.charts.status) {
            this.charts.status.data.labels = newData.status.labels;
            this.charts.status.data.datasets[0].data = newData.status.data;
            this.charts.status.update();
        }
    }
}

// Inicialização global
window.dashboardApp = new DashboardApp();

// Exportar para uso em outros scripts se necessário
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DashboardApp, ToastManager };
}