"""
Modelo para Conta
"""
from dataclasses import dataclass
from typing import Optional, List, Dict
from decimal import Decimal
from app.utils.database import get_db_connection
from app.utils.formatters import format_currency


@dataclass
class Conta:
    """Modelo de dados para Conta"""
    id: Optional[int] = None
    id_fornecedor: Optional[int] = None
    site: Optional[str] = None
    login: Optional[str] = None
    senha: Optional[str] = None
    status: str = 'Não Utilizada'
    saldo: float = 0.0
    lucro: float = 0.0
    fornecedor_nome: Optional[str] = None  # Para joins
    observacoes: Optional[str] = None
    data_criacao: Optional[str] = None
    data_ultima_utilizacao: Optional[str] = None
    data_limitada: Optional[str] = None
    
    # Status válidos
    STATUS_CHOICES = ['Disponível', 'Em Uso', 'Limitada', 'Não Utilizada']
    
    def __post_init__(self):
        """Validação após inicialização"""
        if self.site and len(self.site.strip()) == 0:
            raise ValueError("Nome do site não pode estar vazio")
        if self.status and self.status not in self.STATUS_CHOICES:
            raise ValueError(f"Status deve ser um dos: {', '.join(self.STATUS_CHOICES)}")
    
    @classmethod
    def get_all(cls) -> List['Conta']:
        """Retorna todas as contas com nome do fornecedor"""
        try:
            conn = get_db_connection()
            query = """
                SELECT c.*, f.nome as fornecedor_nome
                FROM contas c
                JOIN fornecedores f ON c.id_fornecedor = f.id
                ORDER BY f.nome, c.site
            """
            results = conn.execute(query).fetchall()
            conn.close()
            
            return [cls._from_db_row(row) for row in results]
        except Exception as e:
            raise Exception(f"Erro ao buscar contas: {str(e)}")
    
    @classmethod
    def get_by_fornecedor(cls, fornecedor_id: int) -> List['Conta']:
        """Retorna contas de um fornecedor específico"""
        if not fornecedor_id:
            return []
            
        try:
            conn = get_db_connection()
            query = """
                SELECT c.*, f.nome as fornecedor_nome
                FROM contas c
                JOIN fornecedores f ON c.id_fornecedor = f.id
                WHERE c.id_fornecedor = ?
                ORDER BY c.site
            """
            results = conn.execute(query, (fornecedor_id,)).fetchall()
            conn.close()
            
            return [cls._from_db_row(row) for row in results]
        except Exception as e:
            raise Exception(f"Erro ao buscar contas do fornecedor: {str(e)}")
    
    @classmethod
    def get_by_site(cls, site_name: str) -> List['Conta']:
        """Retorna contas de um site específico"""
        if not site_name:
            return []
            
        try:
            conn = get_db_connection()
            query = """
                SELECT c.*, f.nome as fornecedor_nome
                FROM contas c
                JOIN fornecedores f ON c.id_fornecedor = f.id
                WHERE c.site = ?
                ORDER BY f.nome
            """
            results = conn.execute(query, (site_name,)).fetchall()
            conn.close()
            
            return [cls._from_db_row(row) for row in results]
        except Exception as e:
            raise Exception(f"Erro ao buscar contas do site: {str(e)}")
    
    @classmethod
    def get_by_id(cls, conta_id: int) -> Optional['Conta']:
        """Retorna uma conta por ID"""
        if not conta_id:
            return None
            
        try:
            conn = get_db_connection()
            query = """
                SELECT c.*, f.nome as fornecedor_nome
                FROM contas c
                JOIN fornecedores f ON c.id_fornecedor = f.id
                WHERE c.id = ?
            """
            result = conn.execute(query, (conta_id,)).fetchone()
            conn.close()
            
            return cls._from_db_row(result) if result else None
        except Exception as e:
            raise Exception(f"Erro ao buscar conta: {str(e)}")
    
    @classmethod
    def _from_db_row(cls, row) -> 'Conta':
        """Cria instância a partir de linha do banco"""
        return cls(
            id=row['id'],
            id_fornecedor=row['id_fornecedor'],
            site=row['site'],
            login=row['login'],
            senha=row['senha'],
            status=row['status'],
            saldo=row['saldo'] or 0.0,
            lucro=row['lucro'] or 0.0,
            fornecedor_nome=row['fornecedor_nome'] if 'fornecedor_nome' in row.keys() else None,
            observacoes=row['observacoes'] if 'observacoes' in row.keys() else None,
            data_criacao=row['data_criacao'] if 'data_criacao' in row.keys() else None,
            data_ultima_utilizacao=row['data_ultima_utilizacao'] if 'data_ultima_utilizacao' in row.keys() else None,
            data_limitada=row['data_limitada'] if 'data_limitada' in row.keys() else None
        )
    
    def save(self) -> int:
        """Salva ou atualiza a conta no banco"""
        if not self.site or len(self.site.strip()) == 0:
            raise ValueError("Nome do site é obrigatório")
        if not self.id_fornecedor:
            raise ValueError("ID do fornecedor é obrigatório")
        if self.status not in self.STATUS_CHOICES:
            raise ValueError(f"Status inválido: {self.status}")
            
        # Limpar campos
        self.site = self.site.strip()
        if self.login:
            self.login = self.login.strip()
        
        try:
            conn = get_db_connection()
            if self.id is None:
                # Inserir nova
                cursor = conn.cursor()
                cursor.execute(
                    '''INSERT INTO contas 
                       (id_fornecedor, site, login, senha, status, saldo, lucro, observacoes, data_criacao) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))''',
                    (self.id_fornecedor, self.site, self.login, self.senha,
                     self.status, self.saldo, self.lucro, self.observacoes)
                )
                self.id = cursor.lastrowid
                # Definir data_criacao após inserção
                self.data_criacao = conn.execute(
                    'SELECT data_criacao FROM contas WHERE id = ?', (self.id,)
                ).fetchone()['data_criacao']
            else:
                # Atualizar existente
                conn.execute(
                    '''UPDATE contas SET 
                       id_fornecedor=?, site=?, login=?, senha=?, 
                       status=?, saldo=?, lucro=?, observacoes=?, 
                       data_ultima_utilizacao=?, data_limitada=? 
                       WHERE id=?''',
                    (self.id_fornecedor, self.site, self.login, self.senha,
                     self.status, self.saldo, self.lucro, self.observacoes,
                     self.data_ultima_utilizacao, self.data_limitada, self.id)
                )
            
            conn.commit()
            conn.close()
            return self.id
        except Exception as e:
            raise Exception(f"Erro ao salvar conta: {str(e)}")
    
    def delete(self) -> bool:
        """Remove a conta"""
        if not self.id:
            return False
            
        try:
            conn = get_db_connection()
            conn.execute('DELETE FROM contas WHERE id = ?', (self.id,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            raise Exception(f"Erro ao excluir conta: {str(e)}")
    
    def update_from_form(self, form_data: dict):
        """Atualiza dados da conta a partir de dados do formulário"""
        if 'login' in form_data and form_data['login']:
            self.login = form_data['login'].strip()
        
        if 'senha' in form_data and form_data['senha']:
            self.senha = form_data['senha']
        
        if 'status' in form_data:
            if form_data['status'] not in self.STATUS_CHOICES:
                raise ValueError(f"Status inválido: {form_data['status']}")
            self.status = form_data['status']
        
        if 'saldo' in form_data:
            try:
                self.saldo = float(form_data['saldo'] or 0.0)
            except (ValueError, TypeError):
                raise ValueError("Saldo deve ser um número válido")
        
        if 'lucro_adicional' in form_data:
            try:
                adicional = float(form_data['lucro_adicional'] or 0.0)
                self.lucro += adicional
            except (ValueError, TypeError):
                raise ValueError("Lucro adicional deve ser um número válido")
    
    def add_lucro(self, valor: float):
        """Adiciona lucro à conta"""
        if not isinstance(valor, (int, float)):
            raise ValueError("Valor do lucro deve ser numérico")
        self.lucro += valor
    
    def limitar_conta(self, lucro_final: float = None):
        """Ação rápida para limitar conta (zera saldo, registra lucro, muda status)"""
        if lucro_final is not None:
            self.lucro = lucro_final
        self.saldo = 0.0  # Zera saldo pois foi sacado
        self.status = 'Limitada'
        # A data será definida no banco via UPDATE
        result = self.save()
        # Atualizar a data_limitada após salvar
        from app.utils.database import get_db_connection
        conn = get_db_connection()
        conn.execute("UPDATE contas SET data_limitada = datetime('now') WHERE id = ?", (self.id,))
        conn.commit()
        conn.close()
        return result
    
    def marcar_em_uso(self):
        """Marca conta como em uso e atualiza data de última utilização"""
        if self.status == 'Disponível' or self.status == 'Não Utilizada':
            self.status = 'Em Uso'
            result = self.save()
            # Atualizar data_ultima_utilizacao após salvar
            from app.utils.database import get_db_connection
            conn = get_db_connection()
            conn.execute("UPDATE contas SET data_ultima_utilizacao = datetime('now') WHERE id = ?", (self.id,))
            conn.commit()
            conn.close()
            return result
        return False
    
    def marcar_disponivel(self):
        """Marca conta como disponível"""
        if self.status == 'Em Uso' or self.status == 'Não Utilizada':
            self.status = 'Disponível'
            return self.save()
        return False
    
    def depositar(self, valor: float):
        """Adiciona valor ao saldo da conta"""
        if not isinstance(valor, (int, float)) or valor <= 0:
            raise ValueError("Valor do depósito deve ser um número positivo")
        self.saldo += valor
        return self.save()
    
    def get_dias_sem_uso(self) -> int:
        """Calcula quantos dias a conta não é usada"""
        from datetime import datetime, timedelta
        
        if not self.data_ultima_utilizacao:
            # Se nunca foi usada, usar data de criação
            if self.data_criacao:
                try:
                    data_ref = datetime.fromisoformat(self.data_criacao.replace('Z', '+00:00'))
                    return (datetime.now() - data_ref).days
                except:
                    return 0
            return 0
        
        try:
            data_ultimo_uso = datetime.fromisoformat(self.data_ultima_utilizacao.replace('Z', '+00:00'))
            return (datetime.now() - data_ultimo_uso).days
        except:
            return 0
    
    def get_conta_ativa_ha(self) -> str:
        """Retorna há quanto tempo a conta está ativa (formatado)"""
        if not self.data_criacao:
            return "Data desconhecida"
        
        from datetime import datetime
        try:
            data_criacao = datetime.fromisoformat(self.data_criacao.replace('Z', '+00:00'))
            dias = (datetime.now() - data_criacao).days
            
            if dias == 0:
                return "Hoje"
            elif dias == 1:
                return "1 dia"
            elif dias < 30:
                return f"{dias} dias"
            elif dias < 365:
                meses = dias // 30
                return f"{meses} mês" if meses == 1 else f"{meses} meses"
            else:
                anos = dias // 365
                return f"{anos} ano" if anos == 1 else f"{anos} anos"
        except:
            return "Data inválida"
    
    def get_saldo_formatted(self) -> str:
        """Retorna saldo formatado em moeda brasileira"""
        return format_currency(self.saldo)
    
    def get_lucro_formatted(self) -> str:
        """Retorna lucro formatado em moeda brasileira"""
        return format_currency(self.lucro)
    
    def is_ativa(self) -> bool:
        """Verifica se a conta está ativa (Disponível ou Em Uso)"""
        return self.status in ['Disponível', 'Em Uso']
    
    def is_limitada(self) -> bool:
        """Verifica se a conta está limitada"""
        return self.status == 'Limitada'
    
    @classmethod
    def get_estatisticas_gerais(cls) -> Dict[str, any]:
        """Retorna estatísticas gerais das contas"""
        try:
            conn = get_db_connection()
            
            # Buscar todas as contas
            contas = conn.execute('SELECT status, lucro, site, saldo FROM contas').fetchall()
            conn.close()
            
            lucro_total = sum(conta['lucro'] or 0.0 for conta in contas)
            saldo_total = sum(conta['saldo'] or 0.0 for conta in contas)
            
            # Contagem por status
            contagem_status = {'Disponível': 0, 'Em Uso': 0, 'Limitada': 0, 'Não Utilizada': 0}
            lucro_por_site = {}
            
            for conta in contas:
                status = conta['status']
                site = conta['site']
                lucro_conta = conta['lucro'] or 0.0
                
                if status in contagem_status:
                    contagem_status[status] += 1
                
                if site:
                    lucro_por_site[site] = lucro_por_site.get(site, 0.0) + lucro_conta
            
            contas_ativas = contagem_status['Disponível'] + contagem_status['Em Uso']
            contas_limitadas = contagem_status['Limitada']
            
            # Ordenar sites por lucro
            sites_ordenados = sorted(lucro_por_site.items(), key=lambda x: x[1], reverse=True)
            
            return {
                'lucro_total': lucro_total,
                'saldo_total': saldo_total,
                'contas_ativas': contas_ativas,
                'contas_limitadas': contas_limitadas,
                'contagem_status': contagem_status,
                'lucro_por_site': dict(sites_ordenados),
                'sites_ordenados': sites_ordenados
            }
            
        except Exception as e:
            raise Exception(f"Erro ao calcular estatísticas: {str(e)}")
    
    @classmethod
    def get_ranking_fornecedores(cls) -> List[Dict[str, any]]:
        """Retorna ranking dos fornecedores por performance"""
        try:
            conn = get_db_connection()
            query = """
                SELECT 
                    f.id,
                    f.nome,
                    COUNT(c.id) as total_contas,
                    SUM(CASE WHEN c.status IN ('Disponível', 'Em Uso') THEN 1 ELSE 0 END) as contas_ativas,
                    SUM(CASE WHEN c.status = 'Limitada' THEN 1 ELSE 0 END) as contas_limitadas,
                    SUM(c.lucro) as lucro_total,
                    SUM(c.saldo) as saldo_total,
                    AVG(c.lucro) as lucro_medio
                FROM fornecedores f
                LEFT JOIN contas c ON f.id = c.id_fornecedor
                GROUP BY f.id, f.nome
                ORDER BY lucro_total DESC, lucro_medio DESC
            """
            results = conn.execute(query).fetchall()
            conn.close()
            
            ranking = []
            for i, row in enumerate(results, 1):
                ranking.append({
                    'posicao': i,
                    'id': row['id'],
                    'nome': row['nome'],
                    'total_contas': row['total_contas'] or 0,
                    'contas_ativas': row['contas_ativas'] or 0,
                    'contas_limitadas': row['contas_limitadas'] or 0,
                    'lucro_total': row['lucro_total'] or 0.0,
                    'saldo_total': row['saldo_total'] or 0.0,
                    'lucro_medio': row['lucro_medio'] or 0.0,
                    'lucro_total_formatted': format_currency(row['lucro_total'] or 0.0),
                    'saldo_total_formatted': format_currency(row['saldo_total'] or 0.0),
                    'lucro_medio_formatted': format_currency(row['lucro_medio'] or 0.0)
                })
            
            return ranking
            
        except Exception as e:
            raise Exception(f"Erro ao calcular ranking de fornecedores: {str(e)}")
    
    @classmethod
    def get_ranking_sites(cls) -> List[Dict[str, any]]:
        """Retorna ranking das casas de apostas por performance"""
        try:
            conn = get_db_connection()
            query = """
                SELECT 
                    site,
                    COUNT(*) as total_contas,
                    SUM(CASE WHEN status IN ('Disponível', 'Em Uso') THEN 1 ELSE 0 END) as contas_ativas,
                    SUM(CASE WHEN status = 'Limitada' THEN 1 ELSE 0 END) as contas_limitadas,
                    SUM(lucro) as lucro_total,
                    SUM(saldo) as saldo_total,
                    AVG(lucro) as lucro_medio,
                    ROUND(AVG(CASE WHEN status = 'Limitada' THEN 1.0 ELSE 0.0 END) * 100, 1) as taxa_limitacao
                FROM contas
                GROUP BY site
                ORDER BY lucro_total DESC, lucro_medio DESC
            """
            results = conn.execute(query).fetchall()
            conn.close()
            
            ranking = []
            for i, row in enumerate(results, 1):
                ranking.append({
                    'posicao': i,
                    'site': row['site'],
                    'total_contas': row['total_contas'],
                    'contas_ativas': row['contas_ativas'],
                    'contas_limitadas': row['contas_limitadas'],
                    'lucro_total': row['lucro_total'] or 0.0,
                    'saldo_total': row['saldo_total'] or 0.0,
                    'lucro_medio': row['lucro_medio'] or 0.0,
                    'taxa_limitacao': row['taxa_limitacao'] or 0.0,
                    'lucro_total_formatted': format_currency(row['lucro_total'] or 0.0),
                    'saldo_total_formatted': format_currency(row['saldo_total'] or 0.0),
                    'lucro_medio_formatted': format_currency(row['lucro_medio'] or 0.0)
                })
            
            return ranking
            
        except Exception as e:
            raise Exception(f"Erro ao calcular ranking de sites: {str(e)}")
    
    @classmethod
    def get_sugestao_proxima_conta(cls, criterio: str = 'saldo') -> Optional['Conta']:
        """Sugere próxima conta para usar baseada em critérios"""
        try:
            conn = get_db_connection()
            
            if criterio == 'saldo':
                # Conta disponível com maior saldo
                query = """
                    SELECT c.*, f.nome as fornecedor_nome
                    FROM contas c
                    JOIN fornecedores f ON c.id_fornecedor = f.id
                    WHERE c.status IN ('Disponível', 'Não Utilizada') AND c.saldo > 0
                    ORDER BY c.saldo DESC, c.data_ultima_utilizacao ASC
                    LIMIT 1
                """
            elif criterio == 'tempo':
                # Conta não usada há mais tempo
                query = """
                    SELECT c.*, f.nome as fornecedor_nome
                    FROM contas c
                    JOIN fornecedores f ON c.id_fornecedor = f.id
                    WHERE c.status IN ('Disponível', 'Não Utilizada')
                    ORDER BY 
                        CASE WHEN c.data_ultima_utilizacao IS NULL THEN c.data_criacao 
                             ELSE c.data_ultima_utilizacao END ASC,
                        c.saldo DESC
                    LIMIT 1
                """
            else:  # critério balanceado
                query = """
                    SELECT c.*, f.nome as fornecedor_nome
                    FROM contas c
                    JOIN fornecedores f ON c.id_fornecedor = f.id
                    WHERE c.status IN ('Disponível', 'Não Utilizada')
                    ORDER BY 
                        c.saldo DESC,
                        CASE WHEN c.data_ultima_utilizacao IS NULL THEN c.data_criacao 
                             ELSE c.data_ultima_utilizacao END ASC
                    LIMIT 1
                """
            
            result = conn.execute(query).fetchone()
            conn.close()
            
            return cls._from_db_row(result) if result else None
            
        except Exception as e:
            raise Exception(f"Erro ao sugerir próxima conta: {str(e)}")
    
    @classmethod
    def get_contas_subutilizadas(cls, dias_limite: int = 7) -> List['Conta']:
        """Retorna contas que não são usadas há muito tempo"""
        try:
            conn = get_db_connection()
            query = """
                SELECT c.*, f.nome as fornecedor_nome
                FROM contas c
                JOIN fornecedores f ON c.id_fornecedor = f.id
                WHERE c.status IN ('Disponível', 'Não Utilizada')
                AND (
                    (c.data_ultima_utilizacao IS NULL AND date(c.data_criacao) <= date('now', '-' || ? || ' days'))
                    OR 
                    (c.data_ultima_utilizacao IS NOT NULL AND date(c.data_ultima_utilizacao) <= date('now', '-' || ? || ' days'))
                )
                ORDER BY 
                    CASE WHEN c.data_ultima_utilizacao IS NULL THEN c.data_criacao 
                         ELSE c.data_ultima_utilizacao END ASC
            """
            results = conn.execute(query, (dias_limite, dias_limite)).fetchall()
            conn.close()
            
            return [cls._from_db_row(row) for row in results]
            
        except Exception as e:
            raise Exception(f"Erro ao buscar contas subutilizadas: {str(e)}")
    
    def to_dict(self, include_senha: bool = False) -> dict:
        """Converte o objeto em dicionário"""
        data = {
            'id': self.id,
            'id_fornecedor': self.id_fornecedor,
            'site': self.site,
            'login': self.login,
            'status': self.status,
            'saldo': self.saldo,
            'lucro': self.lucro,
            'saldo_formatted': self.get_saldo_formatted(),
            'lucro_formatted': self.get_lucro_formatted(),
            'fornecedor_nome': self.fornecedor_nome,
            'observacoes': self.observacoes,
            'data_criacao': self.data_criacao,
            'data_ultima_utilizacao': self.data_ultima_utilizacao,
            'data_limitada': self.data_limitada,
            'dias_sem_uso': self.get_dias_sem_uso(),
            'conta_ativa_ha': self.get_conta_ativa_ha()
        }
        
        if include_senha:
            data['senha'] = self.senha
            
        return data
