-- Remove as tabelas antigas se elas existirem
DROP TABLE IF EXISTS fornecedores;
DROP TABLE IF EXISTS contas;

-- Cria a tabela para armazenar os fornecedores de contas
CREATE TABLE fornecedores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    contato TEXT
);

-- Cria a tabela para armazenar as contas e seus status
CREATE TABLE contas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    id_fornecedor INTEGER NOT NULL,
    site TEXT NOT NULL,
    login TEXT, -- NOVO CAMPO
    senha TEXT, -- NOVO CAMPO
    status TEXT NOT NULL,
    saldo REAL DEFAULT 0.0,
    lucro REAL DEFAULT 0.0,
    FOREIGN KEY (id_fornecedor) REFERENCES fornecedores (id)
);