import sqlite3
import json
import os
from flask import Flask, render_template, request, redirect, url_for, jsonify

app = Flask(__name__)

# ---------------------------
# Filtro Jinja para formatar moeda
# ---------------------------
def format_brl(value):
    """Filtro Jinja para formatar valor como moeda BRL (R$ 1.234,56)."""
    if not isinstance(value, (int, float)):
        return value
    return f"R$ {value:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')

app.jinja_env.filters['brl'] = format_brl


# ---------------------------
# Utilidades
# ---------------------------

def get_logo_path(site_name: str) -> str:
    """
    Retorna o caminho relativo do logo (em /static/logos).
    Se não existir o logo para o site, usa 'default.png'.
    """
    logo_filename = f"{site_name.lower().replace(' ', '')}.png"
    logo_filepath = os.path.join('static', 'logos', logo_filename)
    return f"logos/{logo_filename}" if os.path.exists(logo_filepath) else "logos/default.png"


def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn


# ---------------------------
# Contexto global (cards + gráficos + sidebar)
# ---------------------------
def get_global_context():
    conn = get_db_connection()

    fornecedores = conn.execute(
        'SELECT * FROM fornecedores ORDER BY LOWER(nome)'
    ).fetchall()

    contas_gerais = conn.execute(
        'SELECT status, lucro, site, saldo FROM contas'
    ).fetchall()

    conn.close()

    lucro_total = 0.0
    saldo_total = 0.0
    contas_ativas = 0
    contas_limitadas = 0
    lucro_por_site = {}
    contagem_status = {'Disponível': 0, 'Em Uso': 0, 'Limitada': 0}

    for conta in contas_gerais:
        lucro_total += conta['lucro'] or 0.0
        saldo_total += conta['saldo'] or 0.0

        status_atual = conta['status']
        site = conta['site']

        if site:
            lucro_por_site[site] = lucro_por_site.get(site, 0.0) + (conta['lucro'] or 0.0)

        if status_atual in contagem_status:
            contagem_status[status_atual] += 1

        if status_atual == 'Limitada':
            contas_limitadas += 1
        elif status_atual in ['Disponível', 'Em Uso']:
            contas_ativas += 1

    sites_ordenados = sorted(lucro_por_site.items(), key=lambda item: item[1], reverse=True)
    labels_status = list(contagem_status.keys())
    dados_status = list(contagem_status.values())

    return {
        'fornecedores': fornecedores,
        'lucro_total': lucro_total,
        'saldo_total': saldo_total,
        'contas_ativas': contas_ativas,
        'contas_limitadas': contas_limitadas,
        'grafico_site_labels': json.dumps([item[0] for item in sites_ordenados]),
        'grafico_site_data': json.dumps([item[1] for item in sites_ordenados]),
        'grafico_status_labels': json.dumps(labels_status),
        'grafico_status_data': json.dumps(dados_status)
    }


# ---------------------------
# Rotas
# ---------------------------

@app.route('/')
def index():
    contexto = get_global_context()
    contexto['fornecedor_selecionado'] = None
    return render_template('dashboard.html', **contexto)


@app.route('/provider/<int:provider_id>')
def provider_dashboard(provider_id):
    contexto = get_global_context()
    conn = get_db_connection()
    fornecedor = conn.execute(
        'SELECT * FROM fornecedores WHERE id = ?', (provider_id,)
    ).fetchone()
    if not fornecedor:
        conn.close()
        return redirect(url_for('index'))

    contas_db = conn.execute(
        'SELECT * FROM contas WHERE id_fornecedor = ? ORDER BY site', (provider_id,)
    ).fetchall()
    conn.close()

    tabela_dados = []
    for conta in contas_db:
        d = dict(conta)
        d['logo_path'] = get_logo_path(conta['site'])
        tabela_dados.append(d)

    contexto['fornecedor_selecionado'] = fornecedor
    contexto['tabela_dados'] = tabela_dados
    return render_template('dashboard.html', **contexto)


@app.route('/site/<site_name>')
def site_dashboard(site_name):
    """
    Dashboard por Site (padronizado com o geral/fornecedor):
    - cards de total do site
    - tabela de contas desse site (com fornecedor dono)
    - filtros/ordenar/busca iguais ao dashboard principal
    """
    contexto = get_global_context()
    conn = get_db_connection()
    query = """
        SELECT c.*, f.nome as fornecedor_nome
        FROM contas c
        JOIN fornecedores f ON c.id_fornecedor = f.id
        WHERE c.site = ?
        ORDER BY f.nome
    """
    contas = conn.execute(query, (site_name,)).fetchall()
    conn.close()

    lucro_total_site = 0.0
    saldo_total_site = 0.0
    contas_ativas_site = 0
    contas_limitadas_site = 0

    tabela_dados = []
    for conta in contas:
        lucro_total_site += conta['lucro'] or 0.0
        saldo_total_site += conta['saldo'] or 0.0

        if conta['status'] == 'Limitada':
            contas_limitadas_site += 1
        elif conta['status'] in ['Disponível', 'Em Uso']:
            contas_ativas_site += 1

        d = dict(conta)
        d['logo_path'] = get_logo_path(site_name)
        tabela_dados.append(d)

    contexto.update({
        'site_selecionado': site_name,
        'contas_do_site': tabela_dados,  # agora com logo + fornecedor_nome
        'lucro_total_site': lucro_total_site,
        'saldo_total_site': saldo_total_site,
        'contas_ativas_site': contas_ativas_site,
        'contas_limitadas_site': contas_limitadas_site
    })
    return render_template('site_dashboard.html', **contexto)


# --------- Ações de CRUD e APIs usadas pelo front ---------

@app.route('/update_conta', methods=['POST'])
def update_conta():
    conn = get_db_connection()
    id_conta = request.form.get('id_conta')

    novo_login = request.form.get('login')
    nova_senha = request.form.get('senha')
    novo_status = request.form.get('status')
    novo_saldo = float(request.form.get('saldo', 0.0) or 0.0)
    lucro_adicional = float(request.form.get('lucro_adicional', 0.0) or 0.0)

    conta = conn.execute('SELECT * FROM contas WHERE id = ?', (id_conta,)).fetchone()
    if not conta:
        conn.close()
        return jsonify({'success': False, 'message': 'Conta não encontrada.'}), 404

    novo_lucro = (conta['lucro'] or 0.0) + lucro_adicional

    if nova_senha:
        conn.execute(
            'UPDATE contas SET login=?, senha=?, status=?, saldo=?, lucro=? WHERE id=?',
            (novo_login, nova_senha, novo_status, novo_saldo, novo_lucro, id_conta)
        )
    else:
        conn.execute(
            'UPDATE contas SET login=?, status=?, saldo=?, lucro=? WHERE id=?',
            (novo_login, novo_status, novo_saldo, novo_lucro, id_conta)
        )

    conn.commit()
    conta_atualizada = conn.execute('SELECT * FROM contas WHERE id = ?', (id_conta,)).fetchone()
    conn.close()
    return jsonify({'success': True, 'message': 'Conta atualizada!', 'conta': dict(conta_atualizada)})


@app.route('/add_site', methods=['POST'])
def add_site():
    id_fornecedor = request.form.get('id_fornecedor')
    nome_site = request.form.get('nome_site')
    login = request.form.get('login')
    senha = request.form.get('senha')

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        'INSERT INTO contas (id_fornecedor,site,login,senha,status,saldo,lucro) VALUES (?,?,?,?,?,?,?)',
        (id_fornecedor, nome_site, login, senha, 'Não Utilizada', 0.0, 0.0)
    )
    novo_id = cur.lastrowid
    conn.commit()
    nova_conta = conn.execute('SELECT * FROM contas WHERE id = ?', (novo_id,)).fetchone()
    conn.close()

    conta_dict = dict(nova_conta)
    conta_dict['logo_path'] = get_logo_path(nome_site)

    return jsonify({'success': True, 'message': 'Site adicionado!', 'conta': conta_dict})


@app.route('/get_credentials/<int:conta_id>')
def get_credentials(conta_id):
    conn = get_db_connection()
    conta = conn.execute('SELECT login, senha FROM contas WHERE id = ?', (conta_id,)).fetchone()
    conn.close()
    if not conta:
        return jsonify({'success': False, 'message': 'Credenciais não encontradas.'})
    return jsonify({'success': True, 'login': conta['login'], 'senha': conta['senha']})


@app.route('/delete_site', methods=['POST'])
def delete_site():
    conta_id = request.form.get('conta_id')
    if not conta_id:
        return jsonify({'success': False, 'message': 'ID da conta não fornecido.'}), 400

    conn = get_db_connection()
    conn.execute('DELETE FROM contas WHERE id = ?', (conta_id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'Conta excluída com sucesso!'})


@app.route('/add_provider', methods=['POST'])
def add_provider():
    nome = request.form.get('nome_fornecedor')
    contato = request.form.get('contato_fornecedor')
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO fornecedores (nome, contato) VALUES (?, ?)', (nome, contato))
    novo_id = cur.lastrowid
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'provider': {'id': novo_id, 'nome': nome}})


@app.route('/delete_provider', methods=['POST'])
def delete_provider():
    id_fornecedor = request.form.get('id_fornecedor')
    conn = get_db_connection()
    conn.execute('DELETE FROM contas WHERE id_fornecedor = ?', (id_fornecedor,))
    conn.execute('DELETE FROM fornecedores WHERE id = ?', (id_fornecedor,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})


if __name__ == '__main__':
    app.run(debug=True)