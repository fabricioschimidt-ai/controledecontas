# init_db.py
import sqlite3

# Conecta ao banco de dados (cria o arquivo se não existir)
connection = sqlite3.connect('database.db')

# Abre o arquivo com o esquema do banco de dados (schema.sql)
# Usar um arquivo separado é uma boa prática
with open('schema.sql') as f:
    connection.executescript(f.read())

# Cria um "cursor" para executar comandos
cur = connection.cursor()

# (Opcional) Você pode inserir alguns dados iniciais aqui se quiser
# Exemplo:
# cur.execute("INSERT INTO fornecedores (nome, contato) VALUES (?, ?)",
#             ('Fornecedor Exemplo', 'contato@exemplo.com'))

# Salva as alterações e fecha a conexão
connection.commit()
connection.close()

print("Banco de dados inicializado com sucesso.")