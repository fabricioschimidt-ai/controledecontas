// Conteúdo para static/js/dashboard_logic.js

$(function () {
  // ======== Gráficos =========
  // Nota: As variáveis do Jinja (como grafico_site_labels) não funcionarão aqui diretamente.
  // A melhor abordagem é passar os dados via atributos data-* no HTML ou usar uma tag de script separada para inicializar os dados.
  // Por enquanto, vamos manter a inicialização no HTML para simplicidade.

  // ======== Toast util =========
  function showToast(title, body, isError = false) {
    $('#toastTitle').text(title);
    $('#toastBody').text(body);
    const head = $('#liveToast .toast-header');
    head.removeClass('bg-success bg-danger');
    head.addClass(isError ? 'bg-danger' : 'bg-success');
    $('#liveToast').toast({ delay: 3000 }).toast('show');
  }

  // ======== Busca e Filtro (Comum para ambas as páginas) =========
  $('#searchInput').on('keyup', function () {
    const q = $(this).val().toLowerCase();
    $('#accountsTable tbody tr').each(function () {
      const txt = $(this).text().toLowerCase();
      $(this).toggle(txt.includes(q));
    });
  });

  $('.filter-status').on('click', function () {
    const status = $(this).data('status').toLowerCase();
    $('.filter-status').removeClass('active');
    $(this).addClass('active');
    $('#accountsTable tbody tr').each(function () {
      if (!status) return $(this).show();
      const col = $(this).find('.status-cell').text().toLowerCase();
      $(this).toggle(col.includes(status));
    });
  });

  // ======== Sidebar CRUD de fornecedor (Comum para ambas as páginas) =========
  $('#addProviderForm').on('submit', function (e) {
    e.preventDefault();
    // A URL será lida de um atributo data-* no formulário
    const url = $(this).data('url'); 
    fetch(url, { method: 'POST', body: new FormData(this) })
      .then(r => r.json()).then(d => {
        if (d.success) {
          $('#addProviderModal').modal('hide'); this.reset();
          showToast('Sucesso!', 'Fornecedor adicionado.');
          const p = d.provider;
          const newProviderLink = `/provider/${p.id}`; // Link para o novo fornecedor
          const li = `<li class="nav-item" id="provider-${p.id}">
              <a href="${newProviderLink}" class="nav-link list-group-item d-flex justify-content-between align-items-center">
                <span class="text-truncate"><i class="nav-icon fas fa-user mr-2"></i>${p.nome}</span>
                <button class="btn btn-danger btn-xs btn-delete" aria-label="Excluir fornecedor ${p.nome}" data-provider-id="${p.id}" data-provider-name="${p.nome}" title="Excluir Fornecedor"><i class="fas fa-trash"></i></button>
              </a></li>`;
          $('#provider-list').children().last().before(li);
        }
      });
  });

  $('#provider-list').on('click', '.btn-delete', function (e) {
    e.preventDefault(); e.stopPropagation();
    const id = $(this).data('provider-id'), name = $(this).data('provider-name');
    const url = $('#addProviderForm').data('delete-url'); // Pega a URL de um local consistente
    if (confirm(`Tem certeza que deseja excluir ${name} e TODAS as suas contas?`)) {
      const fd = new FormData(); fd.append('id_fornecedor', id);
      fetch(url, { method: 'POST', body: fd })
        .then(r => r.json()).then(d => {
          if (d.success) {
            showToast('Sucesso!', `${name} foi excluído.`);
            $(`#provider-${id}`).remove();
            // Redireciona se estiver na página do fornecedor excluído
            if (window.location.pathname.includes(`/provider/${id}`)) { 
                window.location.href = $('#addProviderForm').data('index-url'); 
            }
          }
        })
    }
  });
  
  // ======== Ordenação da Tabela (Comum para ambas as páginas) =========
  $('.sortable').on('click', function () {
    const column = $(this).data('column');
    const tbody = $('#accountsTable tbody');
    const rows = tbody.find('tr').toArray();
    const direction = $(this).hasClass('sort-asc') ? 'desc' : 'asc';
    $('.sortable').removeClass('sort-asc sort-desc');
    $(this).addClass(direction === 'asc' ? 'sort-asc' : 'sort-desc');

    rows.sort(function (a, b) {
      let A = $(a).find('td').eq(column).text().trim();
      let B = $(b).find('td').eq(column).text().trim();
      // Converte para número se for coluna de saldo ou lucro
      if (column === 2 || column === 3) { 
        A = parseFloat(A.replace('R$', '').replace(/\./g, '').replace(',', '.').trim());
        B = parseFloat(B.replace('R$', '').replace(/\./g, '').replace(',', '.').trim());
      }
      if (A < B) return direction === 'asc' ? -1 : 1;
      if (A > B) return direction === 'asc' ? 1 : -1;
      return 0;
    });

    tbody.empty().append(rows);
  });

  // ======== Ações específicas da Tabela do dashboard.html =========
  if ($('#accountsTable').length > 0 && $('#addSiteForm').length > 0) {
      const updateUrl = $('#editAccountForm').data('url');
      const deleteUrl = $('#addSiteForm').data('delete-url');
      const addUrl = $('#addSiteForm').data('url');

      $('#editAccountForm').on('submit', function (e) {
          e.preventDefault();
          fetch(updateUrl, { method: 'POST', body: new FormData(this) })
              .then(r => r.json()).then(data => { if (data.success) location.reload(); });
      });

      $('#accountsTable').on('click', '.btn-edit', function () {
          const b = $(this);
          $('#modalContaId').val(b.data('conta-id'));
          $('#editModalLabel').text('Editar Conta: ' + b.data('site'));
          $('#modalLogin').val(b.data('login'));
          $('#modalSenha').val('');
          $('#modalStatus').val(b.data('status'));
          // O valor de saldo e lucro deve ser numérico (sem R$)
          const saldo = b.data('saldo').toString().replace('.', ',');
          const lucro = b.data('lucro').toString().replace('.', ',');
          $('#modalSaldo').val(saldo);
          $('#modalLucroAtual').text(lucro);
          $('#editModal').modal('show');
      });

      $('#accountsTable').on('click', '.btn-view-credentials', function () {
          const id = $(this).data('conta-id');
          // A URL base é pega de um atributo
          const baseUrl = $('#accountsTable').data('credentials-url-base');
          fetch(`${baseUrl}/${id}`).then(r => r.json()).then(d => {
              if (d.success) {
                  $('#viewLogin').text(d.login || 'N/A');
                  $('#viewSenha').val(d.senha || '');
                  $('#viewCredentialsModal').modal('show');
              } else {
                  showToast('Erro', d.message, true);
              }
          });
      });

      $('#copyPasswordBtn').on('click', function () {
          const f = document.getElementById('viewSenha');
          f.select(); document.execCommand('copy');
          showToast('Sucesso!', 'Senha copiada para a área de transferência.');
      });

      $('#accountsTable').on('click', '.btn-delete-site', function () {
          const btn = $(this), id = btn.data('conta-id'), site = btn.data('site-name');
          if (confirm(`Tem certeza que deseja excluir a conta do site "${site}"?`)) {
              const fd = new FormData(); fd.append('conta_id', id);
              fetch(deleteUrl, { method: 'POST', body: fd })
                  .then(r => r.json()).then(d => {
                      if (d.success) {
                          showToast('Sucesso!', d.message);
                          $(`#conta-${id}`).fadeOut(300, function () { $(this).remove(); });
                      } else { showToast('Erro!', d.message, true); }
                  }).catch(() => showToast('Erro de Rede!', 'Não foi possível conectar ao servidor.', true));
          }
      });

      $('#addSiteForm').on('submit', function (e) {
          e.preventDefault();
          const form = this;
          fetch(addUrl, { method: 'POST', body: new FormData(form) })
              .then(r => r.json()).then(d => {
                  if (d.success) {
                      $('#addSiteModal').modal('hide'); form.reset();
                      showToast('Sucesso!', d.message);
                      location.reload(); // A forma mais simples de atualizar a tabela e os totais
                  } else { showToast('Erro!', d.message, true); }
              }).catch(() => showToast('Erro de Rede!', 'Não foi possível conectar ao servidor.', true));
      });
  }

});