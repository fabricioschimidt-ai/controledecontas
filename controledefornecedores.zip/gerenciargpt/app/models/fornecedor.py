"""
Modelo para Fornecedor
"""
from dataclasses import dataclass
from typing import Optional, List
import sqlite3
from app.utils.database import get_db_connection


@dataclass
class Fornecedor:
    """Modelo de dados para Fornecedor"""
    id: Optional[int] = None
    nome: Optional[str] = None
    contato: Optional[str] = None
    
    def __post_init__(self):
        """Validação após inicialização"""
        if self.nome and len(self.nome.strip()) == 0:
            raise ValueError("Nome do fornecedor não pode estar vazio")
            
    @classmethod
    def get_all(cls) -> List['Fornecedor']:
        """Retorna todos os fornecedores ordenados por nome"""
        try:
            conn = get_db_connection()
            results = conn.execute(
                'SELECT * FROM fornecedores ORDER BY LOWER(nome)'
            ).fetchall()
            conn.close()
            
            return [cls(
                id=row['id'],
                nome=row['nome'],
                contato=row['contato']
            ) for row in results]
        except Exception as e:
            raise Exception(f"Erro ao buscar fornecedores: {str(e)}")
    
    @classmethod
    def get_by_id(cls, fornecedor_id: int) -> Optional['Fornecedor']:
        """Retorna um fornecedor por ID"""
        if not fornecedor_id:
            return None
            
        try:
            conn = get_db_connection()
            result = conn.execute(
                'SELECT * FROM fornecedores WHERE id = ?', (fornecedor_id,)
            ).fetchone()
            conn.close()
            
            if result:
                return cls(
                    id=result['id'],
                    nome=result['nome'],
                    contato=result['contato']
                )
            return None
        except Exception as e:
            raise Exception(f"Erro ao buscar fornecedor: {str(e)}")
    
    def save(self) -> int:
        """Salva ou atualiza o fornecedor no banco"""
        if not self.nome or len(self.nome.strip()) == 0:
            raise ValueError("Nome é obrigatório")
            
        self.nome = self.nome.strip()
        if self.contato:
            self.contato = self.contato.strip()
        
        try:
            conn = get_db_connection()
            if self.id is None:
                # Inserir novo
                cursor = conn.cursor()
                cursor.execute(
                    'INSERT INTO fornecedores (nome, contato) VALUES (?, ?)',
                    (self.nome, self.contato)
                )
                self.id = cursor.lastrowid
            else:
                # Atualizar existente
                conn.execute(
                    'UPDATE fornecedores SET nome = ?, contato = ? WHERE id = ?',
                    (self.nome, self.contato, self.id)
                )
            
            conn.commit()
            conn.close()
            return self.id
        except Exception as e:
            raise Exception(f"Erro ao salvar fornecedor: {str(e)}")
    
    def delete(self) -> bool:
        """Remove o fornecedor e suas contas"""
        if not self.id:
            return False
            
        try:
            conn = get_db_connection()
            # Remove contas associadas primeiro
            conn.execute('DELETE FROM contas WHERE id_fornecedor = ?', (self.id,))
            # Remove o fornecedor
            conn.execute('DELETE FROM fornecedores WHERE id = ?', (self.id,))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            raise Exception(f"Erro ao excluir fornecedor: {str(e)}")
    
    def get_contas_count(self) -> int:
        """Retorna o número de contas do fornecedor"""
        if not self.id:
            return 0
            
        try:
            conn = get_db_connection()
            result = conn.execute(
                'SELECT COUNT(*) as count FROM contas WHERE id_fornecedor = ?',
                (self.id,)
            ).fetchone()
            conn.close()
            return result['count'] if result else 0
        except Exception:
            return 0

    def to_dict(self) -> dict:
        """Converte o objeto em dicionário"""
        return {
            'id': self.id,
            'nome': self.nome,
            'contato': self.contato
        }