/**
 * GerenciarGPT - Theme Manager
 * Gerencia tema escuro/claro com persistência
 */

class ThemeManager {
    constructor() {
        this.currentTheme = this.getStoredTheme() || this.getPreferredTheme();
        this.init();
    }

    init() {
        // Aplicar tema inicial
        this.applyTheme(this.currentTheme);
        
        // Criar botão de toggle
        this.createToggleButton();
        
        // Listener para mudanças de preferência do sistema
        this.setupSystemThemeListener();
        
        // Animação de entrada
        this.addInitialAnimations();
    }

    getStoredTheme() {
        return localStorage.getItem('gerenciarGPT-theme');
    }

    getPreferredTheme() {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }

    setStoredTheme(theme) {
        localStorage.setItem('gerenciarGPT-theme', theme);
    }

    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        this.currentTheme = theme;
        this.setStoredTheme(theme);
        this.updateToggleIcon(theme);
        
        // Trigger evento personalizado para outros componentes
        window.dispatchEvent(new CustomEvent('themeChanged', { 
            detail: { theme: theme } 
        }));
    }

    toggleTheme() {
        const newTheme = this.currentTheme === 'dark' ? 'light' : 'dark';
        this.applyTheme(newTheme);
        
        // Animação de transição suave
        this.addTransitionEffect();
        
        // Feedback haptico se disponível
        if ('vibrate' in navigator) {
            navigator.vibrate(50);
        }
    }

    createToggleButton() {
        // Verificar se o botão já existe
        if (document.querySelector('.theme-toggle')) return;

        const button = document.createElement('button');
        button.className = 'theme-toggle';
        button.setAttribute('aria-label', 'Alternar tema escuro/claro');
        button.setAttribute('title', 'Alternar tema');
        button.innerHTML = this.getToggleIcon(this.currentTheme);
        
        button.addEventListener('click', () => this.toggleTheme());
        
        // Adicionar ao DOM
        document.body.appendChild(button);
        
        // Animação de entrada
        setTimeout(() => {
            button.classList.add('fade-in');
        }, 500);
    }

    getToggleIcon(theme) {
        return theme === 'dark' 
            ? '<i class="fas fa-sun"></i>' 
            : '<i class="fas fa-moon"></i>';
    }

    updateToggleIcon(theme) {
        const button = document.querySelector('.theme-toggle');
        if (button) {
            button.innerHTML = this.getToggleIcon(theme);
            button.setAttribute('title', theme === 'dark' ? 'Modo claro' : 'Modo escuro');
        }
    }

    setupSystemThemeListener() {
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        mediaQuery.addEventListener('change', (e) => {
            // Só muda automaticamente se não há preferência salva
            if (!this.getStoredTheme()) {
                this.applyTheme(e.matches ? 'dark' : 'light');
            }
        });
    }

    addTransitionEffect() {
        // Efeito visual de transição
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            pointer-events: none;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s ease;
        `;
        
        document.body.appendChild(overlay);
        
        // Animar entrada
        setTimeout(() => {
            overlay.style.opacity = '1';
        }, 10);
        
        // Remover após animação
        setTimeout(() => {
            overlay.style.opacity = '0';
            setTimeout(() => {
                if (overlay.parentNode) {
                    overlay.parentNode.removeChild(overlay);
                }
            }, 300);
        }, 200);
    }

    addInitialAnimations() {
        // Adicionar classes de animação aos elementos principais
        const elementsToAnimate = [
            '.main-sidebar',
            '.main-header',
            '.content-wrapper .small-box',
            '.card'
        ];
        
        elementsToAnimate.forEach((selector, index) => {
            const elements = document.querySelectorAll(selector);
            elements.forEach((element, elementIndex) => {
                element.style.opacity = '0';
                element.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                    element.style.opacity = '1';
                    element.style.transform = 'translateY(0)';
                }, (index * 100) + (elementIndex * 50));
            });
        });
    }

    // Método público para outros scripts
    setTheme(theme) {
        if (theme === 'dark' || theme === 'light') {
            this.applyTheme(theme);
        }
    }

    // Método público para obter tema atual
    getCurrentTheme() {
        return this.currentTheme;
    }
}

// Utility functions para animações
const AnimationUtils = {
    // Adiciona efeito de ripple aos botões
    addRippleEffect() {
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('btn') && !e.target.classList.contains('theme-toggle')) {
                const button = e.target;
                const rect = button.getBoundingClientRect();
                const ripple = document.createElement('span');
                const size = Math.max(rect.width, rect.height);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.cssText = `
                    position: absolute;
                    width: ${size}px;
                    height: ${size}px;
                    left: ${x}px;
                    top: ${y}px;
                    background: rgba(255,255,255,0.3);
                    border-radius: 50%;
                    transform: scale(0);
                    animation: ripple 0.6s ease-out;
                    pointer-events: none;
                    z-index: 1;
                `;
                
                // Adicionar CSS da animação se não existir
                if (!document.querySelector('#ripple-style')) {
                    const style = document.createElement('style');
                    style.id = 'ripple-style';
                    style.textContent = `
                        @keyframes ripple {
                            to {
                                transform: scale(4);
                                opacity: 0;
                            }
                        }
                    `;
                    document.head.appendChild(style);
                }
                
                button.appendChild(ripple);
                setTimeout(() => ripple.remove(), 600);
            }
        });
    },

    // Observador de elementos para animações de entrada
    setupScrollAnimations() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });

        // Observar cards e tabelas
        document.querySelectorAll('.card, .table-responsive').forEach(el => {
            observer.observe(el);
        });
    },

    // Smooth scroll para âncoras
    setupSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    },

    // Loading states para botões
    addLoadingStates() {
        document.addEventListener('submit', function(e) {
            const submitBtn = e.target.querySelector('button[type="submit"]');
            if (submitBtn) {
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<span class="loading-spinner"></span> Carregando...';
                submitBtn.disabled = true;
                
                // Restaurar após 3 segundos como fallback
                setTimeout(() => {
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }, 3000);
            }
        });
    }
};

// Inicialização quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar gerenciador de temas
    window.themeManager = new ThemeManager();
    
    // Configurar animações e efeitos
    AnimationUtils.addRippleEffect();
    AnimationUtils.setupScrollAnimations();
    AnimationUtils.setupSmoothScroll();
    AnimationUtils.addLoadingStates();
    
    // Melhorias de acessibilidade
    setupAccessibilityFeatures();
    
    // Console log para desenvolvimento
    console.log('🎨 GerenciarGPT Theme Manager carregado!');
    console.log('📱 Tema atual:', window.themeManager.getCurrentTheme());
});

// Funcionalidades de acessibilidade
function setupAccessibilityFeatures() {
    // Atalhos de teclado
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + D para toggle de tema
        if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
            e.preventDefault();
            window.themeManager.toggleTheme();
        }
        
        // Escape para fechar modais
        if (e.key === 'Escape') {
            const modal = document.querySelector('.modal.show');
            if (modal) {
                $(modal).modal('hide');
            }
        }
    });
    
    // Focus visível para navegação por teclado
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-navigation');
    });
    
    // Adicionar CSS para keyboard navigation
    const style = document.createElement('style');
    style.textContent = `
        .keyboard-navigation *:focus {
            outline: 2px solid var(--color-primary) !important;
            outline-offset: 2px;
        }
        
        .keyboard-navigation .theme-toggle:focus {
            outline: 2px solid white !important;
        }
    `;
    document.head.appendChild(style);
}

// Exportar para uso global
window.GerenciarGPT = {
    ThemeManager: ThemeManager,
    AnimationUtils: AnimationUtils
};